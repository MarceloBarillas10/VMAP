package gmailmbfamily20015.com.vmapvirus;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.TextView;

public class Webpage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webpage);
        String virus = getIntent().getStringExtra("message_key");

        if (virus.equals("Zika")) {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/zika/prevention/protect-yourself-and-others.html");
        } else if (virus.equals("Meningitis")) {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/meningitis/index.html");
        } else if (virus.equals("Dengue Fever")) {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/dengue/prevention/index.html");
        } else if (virus.equals("Chinkungunya")) {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/chikungunya/prevention/index.html");
        } else if (virus.equals("Yellow Fever")) {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/yellowfever/index.html");
        } else if (virus.equals("West Nile Virus")) {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/westnile/prevention/index.html");
        } else if (virus.equals("Malaria")) {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/malaria/prevent_control.html");
        } else if (virus.equals("Cholera")) {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/cholera/preventionsteps.html");
        } else if (virus.equals("Influenza")) {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/flu/consumer/prevention.htm");
        } else if (virus.equals("Pneumonia")) {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/pneumonia/index.html");
        } else if (virus.equals("Strep Throat")) {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/dotw/strepthroat/index.html");
        } else {
            WebView webview = new WebView(this);
            setContentView(webview);
            webview.loadUrl("https://www.cdc.gov/");
        }
    }
}

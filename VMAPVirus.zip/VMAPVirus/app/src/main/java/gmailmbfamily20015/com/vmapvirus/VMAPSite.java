package gmailmbfamily20015.com.vmapvirus;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class VMAPSite extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vmapsite);

        WebView webview = new WebView(this);
        setContentView(webview);
        webview.loadUrl("https://high-keyed-patterns.000webhostapp.com/");

    }
}

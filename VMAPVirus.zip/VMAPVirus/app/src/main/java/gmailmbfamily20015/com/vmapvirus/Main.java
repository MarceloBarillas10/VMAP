package gmailmbfamily20015.com.vmapvirus;

import android.content.Intent;
import android.net.http.HttpResponseCache;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.os.AsyncTask;
import android.view.Menu;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.w3c.dom.Text;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class Main extends Activity implements AdapterView.OnItemSelectedListener {
    private Button button;
    private Button buttonS;
    Spinner spinnerA, spinnerG, spinnerV, spinnerL, spinnerC;
    TextView textD;


        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

                Button btn = (Button) findViewById(R.id.send);
                View.OnClickListener listener = new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(getBaseContext(), "Thank you! We're one step closer to stop an epidemic. Always remember to wash your hands!" , Toast.LENGTH_LONG ).show();
                    }
                };
                btn.setOnClickListener(listener);


            button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                openWebpage();
            }
        });
            buttonS = (Button) findViewById(R.id.SiteSite);
            buttonS.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    openVMAPSite();
                }
            });



            spinnerA = (Spinner) findViewById(R.id.AgeGroup);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.AgeGroup, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerA.setAdapter(adapter);
        spinnerA.setOnItemSelectedListener(this);

        spinnerG = (Spinner) findViewById(R.id.GenderMF);
        adapter = ArrayAdapter.createFromResource(this,R.array.GenderMF, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerG.setAdapter(adapter);
        spinnerG.setOnItemSelectedListener(this);

        spinnerV = (Spinner) findViewById(R.id.VirusZ);
        adapter = ArrayAdapter.createFromResource(this,R.array.VirusZ, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerV.setAdapter(adapter);
        spinnerV.setOnItemSelectedListener(this);

        spinnerL = (Spinner) findViewById(R.id.LocationP);
        adapter = ArrayAdapter.createFromResource(this,R.array.LocationP, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerL.setAdapter(adapter);
        spinnerL.setOnItemSelectedListener(this);

        spinnerC = (Spinner) findViewById(R.id.ConfirmationC);
        adapter = ArrayAdapter.createFromResource(this,R.array.ConfirmationC, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerC.setAdapter(adapter);
        spinnerC.setOnItemSelectedListener(this);

        textD =(TextView) findViewById(R.id.text_view_date);
        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        textD.setText(currentDate);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }



    public void send(View v){
        new Send().execute();
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long l) {

    }
    public void openVMAPSite(){
        Intent intent = new Intent(this, VMAPSite.class);
        startActivity(intent);
    }
    public void openWebpage(){
        Intent intent = new Intent(this, Webpage.class);
        String virus = spinnerV.getSelectedItem().toString();
        intent.putExtra("message_key",virus);
        startActivity(intent);
        }
    @Override
    public void onNothingSelected(AdapterView<?> adapterView){

    }
    class Send extends AsyncTask<String, Void,Long > {

        protected Long doInBackground(String... urls){

            String spinnerAge = spinnerA.getSelectedItem().toString();
            String spinnerGender = spinnerG.getSelectedItem().toString();
            String spinnerVirus = spinnerV.getSelectedItem().toString();
            String spinnerLocation = spinnerL.getSelectedItem().toString();
            String spinnerConfirmation = spinnerC.getSelectedItem().toString();
            String textDate = textD.getText().toString();

            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost("https://high-keyed-patterns.000webhostapp.com/phpcode2.php");

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
                nameValuePairs.add(new BasicNameValuePair("Age", spinnerAge));
                nameValuePairs.add(new BasicNameValuePair("Gender", spinnerGender));
                nameValuePairs.add(new BasicNameValuePair("Virus", spinnerVirus));
                nameValuePairs.add(new BasicNameValuePair("Location",spinnerLocation));
                nameValuePairs.add(new BasicNameValuePair("Confirmed",spinnerConfirmation));
                nameValuePairs.add(new BasicNameValuePair("Date",textDate));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);

            } catch (Exception e) {
                // TODO Auto-generated catch block
            }
            return null;

        }
        protected void OnProgressUpdate(Integer... progress) {

        }

        @Override
        protected void onPostExecute(Long result) {

        }
    }
}
